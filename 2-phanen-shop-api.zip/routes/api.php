<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::group(['middleware' => 'cors'], function(){

    //Auth Admin
    Route::post('admin/login', 'AdminController@login');
    Route::post('admin/register', 'AdminController@register');
    Route::get('admin/logout', 'AdminController@logout');


    //GET DATA
    Route::get('aboutus', 'AboutUsController@index');
    Route::get('homepage', 'HomepageController@index');
    Route::get('productcosmetic', 'ProductCosmeticController@index');
    Route::get('productfashion', 'ProductFashionController@index');
    Route::get('profile', 'ProfileController@index');



    Route::group(['middleware' => 'jwt'], function(){

        //POST
        Route::get('aboutus', 'AboutUsController@store');
        Route::get('homepage', 'HomepageController@store');
        Route::get('productcosmetic', 'ProductCosmeticController@store');
        Route::get('productfashion', 'ProductFashionController@store');
        Route::get('profile', 'ProfileController@store');


        //PUT
        Route::put('admin', 'AdminController@update');
        Route::get('aboutus/{id}', 'AboutUsController@update');
        Route::get('homepage/{id}', 'HomepageController@update');
        Route::get('productcosmetic/{id}', 'ProductCosmeticController@update');
        Route::get('productfashion/{id}', 'ProductFashionController@update');
        Route::get('profile/{id}', 'ProfileController@update');


        // DELETE
        // Route::get('aboutus/{id}', 'AboutUsController@delete');
        // Route::get('homepage/{id}', 'HomepageController@delete');
        Route::get('productcosmetic/{id}', 'ProductCosmeticController@delete');
        Route::get('productfashion/{id}', 'ProductFashionController@delete');
        // Route::get('profile/{id}', 'ProfileController@delete');

    });

});